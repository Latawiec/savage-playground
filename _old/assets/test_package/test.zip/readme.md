I packaged this with:
```
zip -r ./test.zip ./*
```